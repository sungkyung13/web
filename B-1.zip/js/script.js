
    // 메뉴 호버 이벤트
$('.menu > li').hover(
    function() {
        $('.sub-menu').stop().slideDown('slow');
    }, function () {
        $('.sub-menu').stop().slideUp('fast');
    }
);

let slide = $('.slide > img');
let now = 0;
let end = slide.length - 1;

    // 처음에 첫 번째 이미지를 왼쪽에 배치
$(slide[0]).css('left', '0');

setInterval(function() {
    $(slide[now]).animate({'left': '-100%'}, 1000, function(){
        $(this).css('left', '100%');
    });
    now = now >= end ? 0 : now + 1;
    $(slide[now]).animate({'left' : '0'}, 1000);
}, 3000);

//.stop()는 이전 동작을 멈추고 다음 액션-.animate() .slideDown() .slideUp() .show() .hide()등-을 실행하라는 의미로 생략가능 

$(document).ready(function(){
    $(".notice-menu").click(function(){
        $(this).css({
            "border-bottom": "0",
            "background-color": "white"
        });
        $(".gallery-menu").css({
            "border-bottom": "1px solid #000",
            "background-color": "#888"
        });
        $(".gallery").hide();
        $(".notice").show();
    });

    $(".gallery-menu").click(function(){
        $(this).css({
            "border-bottom": "0",
            "background-color" : "white"
        });
        $(".notice-menu").css({
            "border-bottom" : "1px solid #000",
            "background-color" : "#888"
        });
        $(".notice").hide();
        $(".gallery").show();
    });
});


function openPop() {
    $("#pop").show("slow");
}

function closePop() {
    $("#pop").hide("fast");
}
