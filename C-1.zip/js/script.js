$(document).ready(function() {
    $('.menu > li').hover(
        function() {
            $(this).children('.subMenu').stop().slideDown('slow');
        }, 
        function() {
            $(this).children('.subMenu').stop().slideUp('fast');
        }
    );
});

$(document).ready(function() {
    $('.notice-menu').click(function() {
        $(this).css({
            "border-bottom" : "1px solid white",
            "background-color" : "#fff"
        });
        $('.gallery-menu').css({
            "border-bottom" : "1px solid black",
            "background-color" : "gray"
        });
        $('.notice').show();
        $('.gallery').hide();
    });
    $('.gallery-menu').click(function() {
        $(this).css({
            "border-bottom" : "1px solid white",
            "background-color" : "#fff"
        });
        $('.notice-menu').css({
            "border-bottom" : "1px solid black",
            "background-color" : "gray"
        });
        $('.notice').hide();
        $('.gallery').show();
    });
});

function openPop() {
    $('#pop').show('slow');
}

function closePop() {
    $('#pop').hide('slow');
}

$(document).ready(function() {
    var slide = $(".slide > img");
    var sno = 0;
    var eno = slide.length - 1;

    // 처음에 첫 번째 이미지를 표시합니다.
    $(slide[sno]).css("opacity", 1);

    var timer = setInterval(autoslide, 3000);

    function autoslide() {
        $(slide[sno]).stop().animate({
            opacity: 0
        }, 1000);
        sno++;
        if (sno > eno) sno = 0;
        $(slide[sno]).stop().animate({
            opacity: 1
        }, 1000);
    }
});

