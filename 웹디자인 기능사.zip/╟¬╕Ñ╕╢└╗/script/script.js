// html이 로딩 되었을 때 함수를 실행
window.onload = function() {
    $('.menu > li').hover(
        function() {
            // 마우스를 올렸을 때
            $('.menu ul').stop().fadeIn();
        }, function () {
            // 마우스를 뗐을 때
            $('.menu ul').stop().fadeOut();
        }
    );

    $(".slide > a").eq(0).siblings().hide();
    let slideIdx = 0;

    function fadeSlide() {
        slideIdx++;
        if (slideIdx == 3) {
            slideIdx = 0;
        }
        $(".slide > a").fadeOut();
        $(".slide > a").eq(slideIdx).fadeIn();
    }

  setInterval(fadeSlide, 3000);

    $(".n").click(function () { // 공지사항 클릭시
        document.querySelector('.g').style.cssText=`color: white; background-color: black`
        document.querySelector('.n').style.cssText=`color: black; background-color: white`
        $(".gallery").css("z-index", "-1");
    });

    $(".g").click(function () { // 갤러리 클릭시
        document.querySelector('.g').style.cssText=`color: black; background-color: white`
        document.querySelector('.n').style.cssText=`color: white; background-color: black`
        $(".gallery").css("z-index", "10");
    })

    $(".notice li")
    .eq(0)
    .click(function () { // 맨 위에 있는 li를 눌렀을 때
        $(".popup").css("display", "block");
    });

    $(".close-btn").click(function () { // 닫기 버튼을 눌렀을 때
        $(".popup").css("display", "none");
    });
}